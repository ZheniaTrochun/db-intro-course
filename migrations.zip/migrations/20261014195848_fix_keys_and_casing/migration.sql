/*
  Warnings:

  - The primary key for the `supplier` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `supplier` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "brand" DROP CONSTRAINT "brand_supplier_id_fkey";

-- AlterTable
ALTER TABLE "supplier" DROP CONSTRAINT "supplier_pkey",
DROP COLUMN "id",
ADD COLUMN     "supplier_id" SERIAL NOT NULL,
ADD CONSTRAINT "supplier_pkey" PRIMARY KEY ("supplier_id");

-- AddForeignKey
ALTER TABLE "brand" ADD CONSTRAINT "brand_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "supplier"("supplier_id") ON DELETE NO ACTION ON UPDATE CASCADE;
