-- AlterTable
ALTER TABLE "brand" ADD COLUMN     "brand_country" TEXT;
