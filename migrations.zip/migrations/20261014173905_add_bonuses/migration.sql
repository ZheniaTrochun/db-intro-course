-- AlterTable
ALTER TABLE "customer" ADD COLUMN     "bonuses" INTEGER DEFAULT 0;
