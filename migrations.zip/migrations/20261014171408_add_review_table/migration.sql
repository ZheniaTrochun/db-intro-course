-- CreateEnum
CREATE TYPE "order_status_type" AS ENUM ('New', 'In Progress', 'Shipped', 'Delivered', 'Cancelled');

-- CreateTable
CREATE TABLE "brand" (
    "brand_id" SERIAL NOT NULL,
    "brand_title" VARCHAR(100) NOT NULL,

    CONSTRAINT "brand_pkey" PRIMARY KEY ("brand_id")
);

-- CreateTable
CREATE TABLE "category" (
    "category_id" SERIAL NOT NULL,
    "category_title" VARCHAR(100) NOT NULL,

    CONSTRAINT "category_pkey" PRIMARY KEY ("category_id")
);

-- CreateTable
CREATE TABLE "customer" (
    "customer_id" SERIAL NOT NULL,
    "customer_first_name" VARCHAR(100) NOT NULL,
    "customer_last_name" VARCHAR(100) NOT NULL,
    "customer_email" VARCHAR(100) NOT NULL,
    "customer_phone_number" VARCHAR(100) NOT NULL,
    "customer_birth_date" DATE NOT NULL,

    CONSTRAINT "customer_pkey" PRIMARY KEY ("customer_id")
);

-- CreateTable
CREATE TABLE "order_item" (
    "orders_id" INTEGER NOT NULL,
    "product_id" INTEGER NOT NULL,
    "quantity" INTEGER NOT NULL,
    "price" DECIMAL(8,2) NOT NULL,

    CONSTRAINT "order_item_pkey" PRIMARY KEY ("orders_id","product_id")
);

-- CreateTable
CREATE TABLE "orders" (
    "orders_id" SERIAL NOT NULL,
    "customer_id" INTEGER,
    "orders_date" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "orders_price" DECIMAL(8,2) NOT NULL,
    "orders_status" "order_status_type" NOT NULL,
    "orders_delivery_address" TEXT NOT NULL,

    CONSTRAINT "orders_pkey" PRIMARY KEY ("orders_id")
);

-- CreateTable
CREATE TABLE "product" (
    "product_id" SERIAL NOT NULL,
    "brand_id" INTEGER NOT NULL,
    "product_title" VARCHAR(100) NOT NULL,
    "product_price" DECIMAL(8,2) NOT NULL,
    "product_expiration_date" DATE,
    "product_pao_months" INTEGER,
    "product_volume" VARCHAR(50) NOT NULL,
    "product_application_method" TEXT,

    CONSTRAINT "product_pkey" PRIMARY KEY ("product_id")
);

-- CreateTable
CREATE TABLE "product_category" (
    "product_id" INTEGER NOT NULL,
    "category_id" INTEGER NOT NULL,

    CONSTRAINT "product_category_pkey" PRIMARY KEY ("product_id","category_id")
);

-- CreateTable
CREATE TABLE "review" (
    "id" SERIAL NOT NULL,
    "rating" INTEGER NOT NULL,
    "comment" TEXT,
    "productId" INTEGER NOT NULL,

    CONSTRAINT "review_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "brand_brand_title_key" ON "brand"("brand_title");

-- CreateIndex
CREATE UNIQUE INDEX "category_category_title_key" ON "category"("category_title");

-- CreateIndex
CREATE UNIQUE INDEX "customer_customer_email_key" ON "customer"("customer_email");

-- CreateIndex
CREATE UNIQUE INDEX "customer_customer_phone_number_key" ON "customer"("customer_phone_number");

-- AddForeignKey
ALTER TABLE "order_item" ADD CONSTRAINT "order_item_orders_id_fkey" FOREIGN KEY ("orders_id") REFERENCES "orders"("orders_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "order_item" ADD CONSTRAINT "order_item_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("product_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "orders" ADD CONSTRAINT "orders_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "customer"("customer_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "product" ADD CONSTRAINT "product_brand_id_fkey" FOREIGN KEY ("brand_id") REFERENCES "brand"("brand_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "product_category" ADD CONSTRAINT "product_category_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "category"("category_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "product_category" ADD CONSTRAINT "product_category_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("product_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "review" ADD CONSTRAINT "review_productId_fkey" FOREIGN KEY ("productId") REFERENCES "product"("product_id") ON DELETE RESTRICT ON UPDATE CASCADE;
