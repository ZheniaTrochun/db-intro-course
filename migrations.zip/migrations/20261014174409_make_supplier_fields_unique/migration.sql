/*
  Warnings:

  - You are about to alter the column `name` on the `supplier` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(100)`.
  - You are about to alter the column `phone_number` on the `supplier` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(100)`.
  - You are about to alter the column `email` on the `supplier` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(100)`.
  - A unique constraint covering the columns `[phone_number]` on the table `supplier` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[email]` on the table `supplier` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "supplier" ALTER COLUMN "name" SET DATA TYPE VARCHAR(100),
ALTER COLUMN "phone_number" SET DATA TYPE VARCHAR(100),
ALTER COLUMN "email" SET DATA TYPE VARCHAR(100);

-- CreateIndex
CREATE UNIQUE INDEX "supplier_phone_number_key" ON "supplier"("phone_number");

-- CreateIndex
CREATE UNIQUE INDEX "supplier_email_key" ON "supplier"("email");
