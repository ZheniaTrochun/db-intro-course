/*
  Warnings:

  - You are about to drop the column `product_pao_months` on the `product` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "product" DROP COLUMN "product_pao_months";
